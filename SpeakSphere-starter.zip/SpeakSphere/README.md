# SpeakSphere

**Your Journey to Confident English**

A mobile-friendly React + Vite starter website for an interactive English-learning platform.

## Included in this starter
- Responsive dark navy / purple / cyan design
- Five age-based learning paths
- Vocabulary cards and local-device saved-word count
- Interactive 3-question practice quiz with feedback and score
- Mobile-friendly navigation and layout
- A clear placeholder explaining that real account sign-in needs backend setup

## Important: what is not connected yet
This is a working front-end starter, not a finished production learning platform. Real email/password sign-up, login, password reset, cloud-saved progress, and a parent/guardian flow are **not configured**. Supabase must be set up and its keys added securely before enabling real authentication. Do not collect children's personal information until privacy and parental-consent requirements are planned.

## Run locally
Requires Node.js 18 or newer.

```bash
npm install
npm run dev
```

To test a production build:

```bash
npm run build
npm run preview
```

## Put this project on GitHub
1. Download and extract the ZIP.
2. Open your empty `speaksphere` repository on GitHub.
3. Choose **Add file → Upload files**.
4. Upload the contents of the extracted `SpeakSphere` folder (including `package.json`, `index.html`, `src/`, and this README). Upload the files/folders, not the ZIP itself.
5. Commit the changes.

## Deploy with Vercel
1. Sign in to Vercel and choose **Add New → Project**.
2. Import the `speaksphere` GitHub repository.
3. Vercel should detect Vite. Build command: `npm run build`; output directory: `dist`.
4. Select Deploy. Afterward, pushes to the connected GitHub branch can trigger new deployments.

## Next development steps
1. Connect Supabase Auth and a database.
2. Add structured lesson content and more age-appropriate practice activities.
3. Add an installable PWA manifest/service worker and test installation on mobile.
4. Add accessibility, privacy, security, and real-device testing before public launch.
